# Cresta Design System

A design system distilled from the **Cresta 2025 slide template**
(`uploads/Copy of Cresta-template-GOOGLE-SLIDES-2025.pptx`). It gives
agents and designers the tokens, assets, and layouts needed to produce
on-brand Cresta decks, docs, and mocks without reinventing the wheel.

> Cresta is an **AI platform for contact centers** — Agent Assist,
> Virtual Agents, Director / QA, and Conversation Intelligence.
> The tone throughout their brand surfaces is **confident,
> enterprise, outcome-oriented, and understated**. The 2025 slide
> template is the primary source used here.

---

## Source material

| Source | Path | Notes |
|---|---|---|
| 2025 Cresta slide template (pptx) | `uploads/Copy of Cresta-template-GOOGLE-SLIDES-2025.pptx` | 83 slides — title, agenda, section dividers, big-stat, quote, thank-you, layout library |
| Raw extract (images, theme, master, slide text) | `pptx_extract/` | Unzipped. `theme1.xml` is the colour source of truth. |
| Logos & marks | `assets/logo/` | Wordmark + "C-atom" interlocking-loops mark, light & dark |
| Background renders | `assets/backgrounds/` | Chrome-ribbon 3D renders (light + dark), pastel gradients, blue diagonal pattern, dark gradient |

The user was **not** given a Figma link, codebase, or production
web / app access for this pass — everything below is derived from the
slide template. If you have access to Cresta.com or the Cresta
product UI, treat those as the higher-fidelity source and flag
divergence.

---

## Index (what's in this folder)

```
/README.md                      — this file
/SKILL.md                       — portable skill manifest (Claude Code compatible)
/colors_and_type.css            — all tokens (colors, type, spacing, radii, shadow)
/assets/
    logo/                       — wordmark + mark, light + dark variants
    backgrounds/                — chrome renders, pastel gradients, diagonal blue, dark gradient
/slides/
    index.html                  — gallery of sample slides
    *.html                      — one per slide type (Title, Agenda, Section, Stat, Quote, Screens, Grid, ThankYou)
/preview/                       — HTML cards that populate the Design System tab
/pptx_extract/                  — raw unpacked .pptx (reference only)
```

---

## CONTENT FUNDAMENTALS

Cresta is an **enterprise B2B AI company**; the voice is that of a
calm, senior operator talking to a VP of Customer Experience — not a
consumer app.

**Voice & tone**
- **Outcome-first.** Lead with what a customer achieves — revenue,
  AHT, CSAT, containment — not with features. "Increase sales
  conversion 20%" beats "GPT-powered agent assist widget."
- **Confident, not loud.** Superlatives are sparing; numbers do the
  shouting. Avoid marketing exclamation marks and em-dash rhetoric.
- **Specific over abstract.** Name the outcome, the metric, the
  customer segment. Use real enterprise nouns: "contact center,"
  "agent," "QA analyst," "conversation," "playbook."
- **Second person, active voice.** "You see every conversation."
  Not "Conversations are visible to the user."
- **"We" for Cresta, "you" for the reader.** "We built this
  because your team shouldn't…"

**Casing**
- **Sentence case** for headlines and subheads — only the first word
  is capitalised, plus proper nouns. The only ALL-CAPS usage is the
  `LABEL` eyebrow above a title, at small sizes with wide tracking.
- **Title Case** is avoided except in legal footers / product names
  (Agent Assist, Director, Opera).
- **CRESTA** the wordmark is always uppercase — this is a visual
  property of the logo, not copy style.

**Typographic texture**
- Headlines are short — **4–10 words**, rarely wrap past 2 lines.
- Subheads are **one tight sentence**. Body paragraphs stay under
  ~40 words; use more bullets, fewer paragraphs.
- **"I" vs "you":** never first-person singular. "We" for Cresta,
  "your team / your agents / your customers" for the audience.
- **Emoji: no.** Not used in the template and out of place for
  Cresta's enterprise audience. Iconography is line-art or branded
  illustrations (see Iconography).
- **No greetings or filler.** Slides don't say "Welcome!" or
  "Let's dive in!" — they open with the claim.

**Example specimens** (from the template layout library)

> LABEL · `Pre-built layouts`
>
> *Eyebrow paired with a simple noun-phrase title. No verbs, no
> punctuation.*

> `Agenda`
> - Item one
> - Item two
> - Item three
>
> *Plain, unadorned. The template deliberately uses neutral filler
> ("Item label", "Item title", "Caption or descriptive text goes
> here") so the structure is visible.*

> `Thank you`
> `ありがとう · Gracias · 谢谢 · Dhanyavaad`
>
> *Multi-language thank-you is the canonical closing slide — a nod
> to Cresta's global contact-center customer base.*

---

## VISUAL FOUNDATIONS

**Palette**

| Token | Hex | Role |
|---|---|---|
| `--cresta-ink` | `#24242A` | Primary dark text / dark surfaces |
| `--cresta-ink-soft` | `#3C3C47` | Softer slate |
| `--cresta-paper` | `#EBF0F5` | Primary light background |
| `--cresta-blue` | `#2059E3` | Primary accent — CTAs, primary brand colour |
| `--cresta-mist` | `#C1CACE` | Warm neutral |
| `--cresta-apricot` | `#FCB56C` | Warm highlight |
| `--cresta-coral` | `#F87563` | Alert / emphasis |
| `--cresta-sky` | `#93DEFD` | Cool highlight |
| `--cresta-lilac` | `#AE95DD` | Cool accent |

The **lead colour pairing is ink + paper** (near-black on off-white).
The blue is the only true "brand" chroma; the 4-colour accent set
(apricot / coral / sky / lilac) is reserved for data-viz,
illustration accents, and the multi-language "thank you." Everything
else is achromatic.

**Typography** — Barlow (display) + DM Sans (body)
- Barlow is geometric, slightly condensed — matches the `CRESTA`
  wordmark's character. Used for all headlines, big stats, section
  numbers. **Loaded from Google Fonts** (no licensed TTFs provided).
- DM Sans is a warm humanist grotesque — used for body copy,
  captions, labels. **Loaded from local `/fonts`** — full family
  ships with weights 100–900 plus italics, including optical-size
  cuts at 18pt / 24pt / 36pt for extreme sizes.
- Weights used: Barlow 500/600; DM Sans 400/500/600. 700+ is rare.

**Backgrounds** — three families, one per mood
1. **Chrome / iridescent ribbons** (primary) — abstract 3D-rendered
   flowing forms in silver-on-light or silver-on-dark, with subtle
   rainbow dispersion highlights. This is Cresta's signature look
   — polished, AI-inflected, Apple-adjacent. Used for cover and
   section dividers. (`assets/backgrounds/chrome-*.jpg`)
2. **Soft pastel gradients** — blurred coral / lilac / sky /
   apricot washes. Used for lighter section dividers and optimistic
   mood. (`assets/backgrounds/pastel-*.jpg`)
3. **Solid + pattern** — flat `--cresta-ink` or `--cresta-paper`,
   or flat `--cresta-blue` with the **diagonal-stripe band** at
   the bottom (`assets/backgrounds/blue-stripes.png`). Used for
   content slides, quote slides, thank-you.

Hand-drawn illustrations, photography of people, and stock 3D
isometrics are **not** part of this system.

**Corners & shape**
- **Large radii** for hero cards / backgrounds: 16–24px. Pills
  (`--radius-pill`) for tags, status chips, action pills.
- **Smaller radii** for inline UI: 6–10px for buttons, inputs,
  badges.
- Screenshots / product mocks sit in ~16px-radius containers with
  a subtle shadow (shadow-md).

**Shadow / elevation**
- Used **sparingly**. Most elements are flat on flat. Elevation
  appears only for floating product screens over chrome
  backgrounds, and for modals.
- System: `--shadow-xs/sm/md/lg` — see `colors_and_type.css`.
- No inner shadows or neumorphism.

**Borders**
- 1px hairlines at `--border` (slate-200) for cards and dividers.
- Heavier `--border-strong` (slate-300) for inputs on hover.
- No colored left-accent borders. No dashed borders.

**Transparency & blur**
- Chrome backgrounds already do the heavy lifting visually; avoid
  stacking additional `backdrop-filter` effects over them.
- Light overlays on chrome imagery for legibility: 0-30% black
  scrims at the text end of a slide, never as a full-bleed wash.

**Animation**
- The slide template itself is static. When animating:
  - **Easing:** `cubic-bezier(.2, .7, .2, 1)` (gentle out) is the
    house default.
  - **Duration:** 240–360ms for UI, 600–900ms for hero entrance.
  - **Character:** fades + small translates. **No bounces, no
    overshoots, no spring wobble.** Motion should feel like silk,
    matching the chrome-ribbon visuals.

**Hover / press**
- Primary buttons: lighten 8% on hover; darken 6% on press.
- Text links: underline appears on hover (not by default).
- Cards: translate-y(-2px) + shadow step-up on hover.
- No scale transforms on press.

**Imagery vibe**
- **Cool-leaning monochrome**, with warm pastel ribbons as the
  chromatic contrast. No warm-toned photography. No grain. No
  duotones. Renders are always high-gloss, calm, cinematic.

**Layout rules**
- 16:9 slide canvas (1920×1080). Margins: **96px** default, **64px**
  minimum, **48px** on dense layouts.
- 12-column grid at ~160px columns with 24px gutters.
- **Left-aligned** text is the default. Centering is reserved for
  stat hero slides and the Thank-you slide.
- Footer/branding block is pinned bottom-left at 48–64px from
  edges; page number bottom-right.
- The CRESTA wordmark never appears bigger than needed — it is a
  tag, not a hero element, except on the true cover slide.

---

## ICONOGRAPHY

The slide template ships **no icon set** — it contains only the
Cresta wordmark and the "C-atom" brand mark (interlocking loops
forming a C). Where icons are needed on marketing surfaces and
product UI, Cresta's public site uses **thin line-art icons**
(1.5–2px stroke, rounded joins) in monochrome ink.

**Substitution (flagged for user review):**
Since no Cresta icon font or sprite exists in the materials provided,
this system substitutes **[Lucide](https://lucide.dev)** as the
default icon set — it matches the stroke weight and geometric style
of Cresta's marketing icons and is CDN-available:

```html
<script src="https://unpkg.com/lucide@latest"></script>
<i data-lucide="arrow-right"></i>
<script>lucide.createIcons();</script>
```

⚠️ **If you have the real Cresta icon library**, drop SVGs in
`assets/icons/` and update the UI components to reference them
instead.

**Emoji:** never used.
**Unicode glyphs as icons:** avoid. The only acceptable exception
is `→` for CTAs (it reads as part of the typography, not an icon).

**Logos provided** (in `assets/logo/`):
- `cresta-wordmark-dark.png` — full "C-atom + CRESTA" lockup, ink
- `cresta-wordmark-white.png` — full lockup, white
- `cresta-mark-dark.png` / `-white.png` — just the C-atom mark
- `cresta-mark-square.png` / `-tall.png` / `-alt*.png` — variants
  pulled from layout assets

Minimum size: wordmark 120px wide; mark 32px wide. Clear space
equal to the height of the mark on all sides.

---

## How to use this system

**In a new HTML artifact**

```html
<link rel="stylesheet" href="colors_and_type.css">
<body>
  <h1>Outcome-first headline</h1>
  <p class="lead">One-sentence subhead in your brand voice.</p>
</body>
```

**For a Cresta-branded slide deck** — start from
`slides/index.html` and copy the slide type that best fits.

**For a Cresta-branded product mock** — no UI kit exists yet (see
Caveats); use the tokens + logo assets and consult Cresta's public
product pages for high-fidelity reference.

---

## Caveats

- **No codebase, Figma, or product screenshots provided** — the
  system is derived from the slide template only. Product-UI tokens
  (form styles, table styles, navigation patterns) are **not**
  authoritative and should be treated as reasonable guesses that
  match the slide template's tone.
- **Fonts substituted partially.** DM Sans is now loaded from
  local `/fonts` (full family, weights 100–900 + italics, plus
  optical-size cuts). **Barlow** still loads from Google Fonts —
  drop the licensed TTFs into `/fonts` and replace the Google
  Fonts `@import` in `colors_and_type.css` with `@font-face` rules
  to fully self-host.
- **Lucide is a substitute icon set.** See Iconography.
- The chrome-ribbon renders are used as full-bleed backgrounds —
  **do not edit or crop them awkwardly**, and never stretch them
  off their native 16:9.
