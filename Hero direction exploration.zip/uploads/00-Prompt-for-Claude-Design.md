# Prompt for Claude Design

Paste everything below the line into Claude Design. Attach the current page (03-celeste-test-line.html), the files in screenshots/, the brief (01-Design-Brief.md), the copy deck (02-Copy-Deck.md), and the Revinate logo. Also attach the two templates in brand-reference/ if Cresta's design system isn't already set up in Claude Design.

---

I'm attaching a working landing page, screenshots of it, a design brief, and a copy deck. Please redesign the page on Cresta's brand system and co-brand it with Revinate, without changing the content.

**Goal:** a shareable test-line page for Revinate's team. Revinate is a hospitality technology company. Their team will call Celeste, an AI voice agent built on Cresta AI Agent for Fontainebleau Miami Beach, and try to stump her.

**Audience:** Revinate's contact center leaders and product team, opening the link on desktop and on their phones. They run hotel reservation operations; they aren't engineers.

**Primary job:** get people to call the number with a scenario in hand, and set honest expectations about what the test line can't do.

**Layout, in this order:**
1. **Header:** the Cresta and Revinate logo lockup, plus the note "Test line for the Revinate team."
2. **Hero:**
   - Who Celeste is.
   - The phone number as the largest element on the page.
   - "Call Celeste" and "Copy number" buttons.
   - A "What Celeste handles" panel.
3. **How a call works:** three numbered steps.
4. **Scenarios to try:** five cards styled like reservation slips. Each has a stub holding the confirmation number and last name the caller reads to Celeste.
5. **Two columns:** what to expect, next to what this test line doesn't do.
6. **Footer:** contacts and fine print.

**Content:**
- Keep all copy exactly as it is in the copy deck.
- Confirmation numbers, names, dates, and dollar amounts must not change. They match the agent's test data, so any change breaks the calls.
- No em dashes or en dashes anywhere.

**What I want from you:**
- Apply Cresta's design system (type, color, buttons, cards).
- Replace the text wordmarks with the official Cresta logo and the Revinate logo I've attached.
- Keep the phone number as the focal point of the hero.
- Keep the reservation-slip structure on the scenario cards; that's the part that makes the page useful on a call.
- Show me two or three hero directions before you polish the rest of the page.
- Support light and dark mode, work down to 360px wide, and keep visible keyboard focus.

**Don't add:**
- Pricing, pilot, or sales calls to action.
- An end date for the test line.
- A section for the chat or voice widget. They'll float on their own, so leave the bottom-right corner clear on every screen size.
- Resort photography, or Fontainebleau logos or marks.
- Stats, testimonials, or customer logos.

The brief covers the full constraints, the test data, and the technical requirements for the export.
