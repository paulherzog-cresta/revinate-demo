# Celeste Test Line Landing Page: Design Brief

This page gives Revinate's team a phone number for Celeste, a Fontainebleau Miami Beach voice agent built on Cresta AI Agent. It also tells them what to try and what the test line can't do. The content is final. This pass is about branding and polish: real logos, Cresta's design system, and a stronger hero. The structure and the test data stay as they are.

## What's in this package

| File | What it's for |
|---|---|
| 00-Prompt-for-Claude-Design.md | The prompt to paste into Claude Design |
| 01-Design-Brief.md | This brief: constraints, test data, export requirements, QA |
| 02-Copy-Deck.md | Every line of on-page copy, section by section |
| 03-celeste-test-line.html | The current working page (single file, light and dark mode, responsive) |
| screenshots/ | The current page on desktop in light and dark mode, on mobile, and a hero close-up |
| brand-reference/ | Cresta's light and dark slide templates. Upload these only if Cresta's design system isn't already set up in Claude Design. |

Still needed from you:
- The Revinate logo, preferably SVG. Get it from Josh or Revinate's press materials rather than capturing it from their site.
- The Cresta logo, if the design system doesn't already provide it.

## How to run it in Claude Design

1. Start a new design. If Cresta's design system is already set up for the org, the project inherits it, and you can skip the slide templates.
2. Attach the HTML, the screenshots, the brief, the copy deck, and the Revinate logo. Add the two templates if needed.
3. Paste the prompt from 00-Prompt-for-Claude-Design.md.
4. Pick a hero direction, then give specific feedback. "Tighten the gap between the number and the buttons to 16px" works better than "make it cleaner."
5. Export as standalone HTML. Claude Design's internal share link only works inside Cresta's organization, so Josh's team can't use it.
6. After export, run the steps in "Before it goes live" below.

If the Claude Design canvas won't take a .md or .html file, paste the text of this brief and the copy deck into the chat instead.

## Goal, audience, and primary job

- **Goal:** a co-branded page Josh can share with his team so they can test Celeste on their own time.
- **Audience:** Revinate's contact center leaders and product team. They know hotel reservations well and will judge Celeste the way they'd judge a new agent on their floor. They'll open the page on laptops and phones, often while they're on the call.
- **Primary job:** get them to dial with a scenario ready, then keep the confirmation number and last name easy to read mid-call.
- **Secondary job:** set honest expectations. The reservation system is simulated, no one answers transfers, and the line covers Miami Beach only.

## Locked test data

These values are loaded in Celeste's mock reservation tools. If any of them change on the page, the calls stop working.

| Card | Confirmation | Last name | Guest | Room | Dates | Figures shown |
|---|---|---|---|---|---|---|
| The family trip | 52817346 | Bennett | Marcus Bennett, two adults and a five-year-old | Deluxe Bayview Two Queens | Friday, December 11 to Tuesday, December 15, 2026 | None |
| One call, four changes | 63950418 | Raman | Priya Raman | Trésor Ocean View One Bedroom Suite | Thursday, January 14 to Sunday, January 17, 2027 | $269.04 in Hotel Fees and an $800 hold, after adding Sunday night |
| The waiver | 71406285 | Okafor | Daniel Okafor, with Grace on the second room | Two Deluxe Bayview King rooms | Arrives two days after the day of the call, for three nights | $443.46 penalty |
| Booked on Expedia | 94182037 | Alvarez | Sofia Alvarez | Deluxe Bayview King | Thursday, December 17 to Sunday, December 20, 2026 | None |
| Stump her | Any 8 digits | Any name | Caller's choice | Built by the agent | Built by the agent | Numbers starting with 9 come back as Expedia bookings |
| Demo replay (footnote on Stump her) | 84721596 | Whitfield | Dana Whitfield | Two Ocean View King rooms | Arrives two days after the day of the call | None |

All guests, rates, and confirmation numbers are fictional.

## Copy rules

- The copy deck is the source of truth. Don't rewrite, shorten, or add marketing lines.
- No em dashes or en dashes. Use commas, periods, or "to" for ranges.
- Use sentence case for headings and buttons. No all-caps eyebrow labels.
- Use typographic quotes and apostrophes. Keep the quoted "Try asking" lines in quotation marks.
- Use "Celeste" and "she" for the agent, and "Cresta AI Agent" for the product.
- Keep every button label consistent with what it does: "Call Celeste" dials and "Copy number" copies.

## Design direction

**Keep:**
- **The number.** It's the largest thing on the page and it's tappable.
- **The reservation-slip cards.** The stub holds exactly what the caller reads aloud (confirmation number and last name), so it should stay easy to find at a glance. The dashed tear line is a nice touch; keep it or replace it with something that does the same job.
- **The section order** and the "expect versus doesn't do" pairing.
- **The numbered steps.** "How a call works" is the only place numbering belongs, because it's a real sequence.

**Polish:**
- **Logo lockup.** Use the official Cresta and Revinate logos at matched visual weight. Per Cresta's slide brand guide, the multi-color C-ring is reserved for closing slides, so use the standard wordmark unless the web design system says otherwise.
- **Design system.** Apply Cresta's type, color tokens, buttons, and card styles from the design system. The current build uses Carlito as a stand-in for Calibri.
- **Hero.** A stronger composition is welcome. Cresta's soft lavender-to-pink brand gradient (upper right in light mode, deep navy in dark mode) is fine there. Ask for two or three directions.
- **Visual interest.** An abstract brand motif or a simple illustration of a phone call is fine.

**Avoid:**
- Resort photography, and Fontainebleau logos or marks. We don't have rights to them.
- Stats, testimonials, customer logos, pricing, pilot or sales calls to action, or an end date.
- A widget section. The chat and voice widgets float on their own.
- Generic SaaS styling: identical cards with the same soft shadow, gradient washes everywhere, and fade-in animations on every section.
- Motion that isn't a response to the user. Copy confirmation is the only animated moment the page needs.
- Carrying Cresta's slide footer ("Confidential & Proprietary") onto the page. This page is shared outside Cresta.

## Current brand tokens

These are the tokens in the current build, pulled from Cresta's slide brand guide. The web design system should override them where it differs.

| Token | Light | Dark | Use |
|---|---|---|---|
| Background | #F2F3F8 | #0C0C16 | Page |
| Surface | #FFFFFF | #14151F | Cards and the side panel |
| Stub | #ECEEFA | #191C30 | Reservation stub |
| Border | #E2E2EB | #252535 | Card borders |
| Ink | #2D2D35 | #FFFFFF | Body text and headings |
| Muted ink | #5E5E70 | #A3A3B8 | Secondary text (darkened from the slide guide's #9B9BA8 for contrast) |
| Cresta blue | #3D52D5 | #3D52D5 | Buttons and step badges |
| Accent text | #3D52D5 | #93A0F5 | Number, links, and confirmation numbers (lightened in dark mode for contrast) |
| Glow | #E8D5D5 | #1A2545 | Hero gradient |

Type is a single sans family, with Calibri, then Carlito, then Arial as fallbacks. The slide guide calls for no serifs and no mixed families.

## Technical requirements for the export

- **One standalone HTML file** with CSS and JavaScript inline, so it can go on any static host.
- **The CONFIG block.** Keep the script block at the bottom where the phone number (display and dial format) and the two contact emails are set once and filled in everywhere. If the design changes the markup, keep the attributes that script reads: `data-phone`, `data-phone-link`, `data-contact`, plus the `copy-number` and `copy-status` IDs.
- **The noindex tag.** Keep `<meta name="robots" content="noindex, nofollow">`.
- **Light and dark mode.** Follow the system setting through CSS variables under `prefers-color-scheme: dark`. Text must meet WCAG AA contrast in both modes.
- **Responsive.** Down to 360px wide, with no horizontal scroll. On mobile, the number comes before the "What Celeste handles" panel.
- **Widget clearance.** Leave about 120px clear in the bottom-right corner on every screen size, and extra space at the foot of the page.
- **Accessibility.** Visible keyboard focus, real buttons and links, alt text on logos, and `prefers-reduced-motion` respected.
- **Performance.** Logos as inline SVG or small files. No heavy images.

## Open decisions

1. **Recording line.** The footer says calls are recorded and transcribed "so we can review them with your team." Keep it only if you plan to review calls with Revinate.
2. **Testing tips.** The "Stump her" card shares the start-with-9 trick and the November 11 demo reservation. Both help testers, and both reveal how the test data works.
3. **Co-branding.** Confirm with Josh that Revinate's logo can go on a shared page.
4. **Dates.** The line is open-ended, but the family trip (December 11) and the Expedia booking (December 17) go stale after those dates. Plan to swap them if testing runs into December.

## Before it goes live

1. Fill in the CONFIG values: phone display, phone dial digits, and both emails.
2. Add the chat and voice widget embed code.
3. Check every confirmation number, name, date, and dollar amount against the locked test data table.
4. Search the file for em dashes and en dashes. There should be none.
5. Confirm the noindex tag is still in the head.
6. On a phone, tap "Call Celeste" and confirm it dials.
7. Click "Copy number" and confirm the copied number.
8. Check the page in light and dark mode, at 360px and at desktop width, with the widget open.
9. Look for anything internal: pricing, pilot terms, deal notes, or Cresta's confidential footer. There should be none.
